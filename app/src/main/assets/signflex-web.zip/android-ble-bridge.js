/**
 * Android BLE Bridge
 * This script provides a bridge between the Web Bluetooth API and Android native BLE
 * functionality when running in WebView
 */

class AndroidBLEBridge {
  constructor() {
    this.isAndroidApp = localStorage.getItem('IS_ANDROID_APP') === 'true';
    this.hasNativeBLE = typeof AndroidBLEInterface !== 'undefined';
    this.listeners = [];
    this.connected = false;
    this.deviceName = '';
    
    // ESP32 UUIDs
    this.ESP32_SERVICE_UUID = '4fafc201-1fb5-459e-8fcc-c5c9c331914b';
    this.FLEX_CHARACTERISTIC_UUID = 'beb5483e-36e1-4688-b7f5-ea07361b26ac';
    this.BATTERY_CHARACTERISTIC_UUID = 'beb5483e-36e1-4688-b7f5-ea07361b26ad';
    
    console.log('AndroidBLEBridge initialized, isAndroidApp:', this.isAndroidApp, 'hasNativeBLE:', this.hasNativeBLE);
    
    // Setup Android callbacks if in Android app
    if (this.isAndroidApp && this.hasNativeBLE) {
      this.setupAndroidCallbacks();
    }
  }
  
  // Check if running in Android app with native BLE
  isRunningInAndroidApp() {
    return this.isAndroidApp && this.hasNativeBLE;
  }
  
  // Setup callbacks from Android to JS
  setupAndroidCallbacks() {
    // Define global callback functions for Android to call
    window.onBLEConnected = (deviceName) => {
      console.log('Android BLE connected to:', deviceName);
      this.connected = true;
      this.deviceName = deviceName;
      this._notifyListeners('connected', { deviceName });
    };
    
    window.onBLEDisconnected = () => {
      console.log('Android BLE disconnected');
      this.connected = false;
      this._notifyListeners('disconnected', {});
    };
    
    window.onBLEFlexData = (flexValue) => {
      console.log('Android BLE flex data:', flexValue);
      this._notifyListeners('flexDataUpdate', { value: parseInt(flexValue) });
    };
    
    window.onBLEBatteryData = (level, voltage) => {
      console.log('Android BLE battery data - Level:', level, '%, Voltage:', voltage, 'V');
      this._notifyListeners('batteryUpdate', { 
        level: parseInt(level), 
        voltage: parseFloat(voltage)
      });
    };
    
    window.onBLEError = (error) => {
      console.error('Android BLE error:', error);
      this._notifyListeners('error', { message: error });
    };
    
    console.log('Android BLE callbacks registered');
  }
  
  // Scan for and connect to ESP32 device
  async connect() {
    console.log('Attempting to connect to ESP32 device...');
    
    if (this.isRunningInAndroidApp()) {
      // Use native Android BLE
      try {
        console.log('Using Android native BLE...');
        AndroidBLEInterface.scanAndConnect(this.ESP32_SERVICE_UUID);
        return true; // Actual result will come through callbacks
      } catch (error) {
        console.error('Error using Android native BLE:', error);
        throw new Error('Failed to connect using Android native BLE: ' + error.message);
      }
    } else {
      // Use Web Bluetooth API
      if (!('bluetooth' in navigator)) {
        throw new Error('Web Bluetooth API is not supported in this browser');
      }
      
      try {
        console.log('Using Web Bluetooth API...');
        // Request device with ESP32 service UUID
        const device = await navigator.bluetooth.requestDevice({
          filters: [{ services: [this.ESP32_SERVICE_UUID] }]
        });
        
        console.log('Device selected:', device.name);
        this.deviceName = device.name || 'ESP32 Device';
        
        // Add event listener for disconnection
        device.addEventListener('gattserverdisconnected', () => {
          console.log('Device disconnected');
          this.connected = false;
          this._notifyListeners('disconnected', {});
        });
        
        // Connect to GATT server
        console.log('Connecting to GATT server...');
        const server = await device.gatt.connect();
        
        // Get the ESP32 service
        console.log('Getting primary service...');
        const service = await server.getPrimaryService(this.ESP32_SERVICE_UUID);
        
        // Get the flex sensor characteristic
        console.log('Getting flex sensor characteristic...');
        const flexCharacteristic = await service.getCharacteristic(this.FLEX_CHARACTERISTIC_UUID);
        
        // Get the battery characteristic
        console.log('Getting battery characteristic...');
        const batteryCharacteristic = await service.getCharacteristic(this.BATTERY_CHARACTERISTIC_UUID);
        
        // Subscribe to notifications for flex sensor
        await flexCharacteristic.startNotifications();
        flexCharacteristic.addEventListener('characteristicvaluechanged', (event) => {
          try {
            const value = event.target.value;
            const dataView = new DataView(value.buffer);
            const flexValue = dataView.getUint16(0, true);
            this._notifyListeners('flexDataUpdate', { value: flexValue });
          } catch (error) {
            console.error('Error parsing flex sensor data:', error);
          }
        });
        
        // Subscribe to notifications for battery
        await batteryCharacteristic.startNotifications();
        batteryCharacteristic.addEventListener('characteristicvaluechanged', (event) => {
          try {
            const value = event.target.value;
            const dataView = new DataView(value.buffer);
            const level = dataView.getUint8(0);
            const voltage = dataView.getFloat32(1, true);
            this._notifyListeners('batteryUpdate', { level, voltage });
          } catch (error) {
            console.error('Error parsing battery data:', error);
          }
        });
        
        console.log('BLE connection successful!');
        this.connected = true;
        
        this._notifyListeners('connected', { deviceName: this.deviceName });
        
        return true;
      } catch (error) {
        console.error('BLE connection error:', error);
        this.connected = false;
        throw error;
      }
    }
  }
  
  // Disconnect from device
  async disconnect() {
    if (this.isRunningInAndroidApp()) {
      try {
        AndroidBLEInterface.disconnect();
        return true;
      } catch (error) {
        console.error('Error disconnecting with Android native BLE:', error);
        throw error;
      }
    } else {
      // Web BLE disconnection is handled by event listener
      this._notifyListeners('disconnected', {});
      return true;
    }
  }
  
  // Add listener for events
  addListener(event, callback) {
    this.listeners.push({ event, callback });
    return () => {
      this.listeners = this.listeners.filter(listener => 
        listener.event !== event || listener.callback !== callback
      );
    };
  }
  
  // Notify all listeners of an event
  _notifyListeners(event, data) {
    this.listeners
      .filter(listener => listener.event === event)
      .forEach(listener => {
        try {
          listener.callback(data);
        } catch (e) {
          console.error(`Error in listener for ${event}:`, e);
        }
      });
  }
  
  // Check if device is connected
  isConnected() {
    return this.connected;
  }
  
  // Get connected device name
  getDeviceName() {
    return this.deviceName;
  }
}

// Create and export a singleton instance
const androidBLEBridge = new AndroidBLEBridge();
window.androidBLEBridge = androidBLEBridge;

export default androidBLEBridge;
